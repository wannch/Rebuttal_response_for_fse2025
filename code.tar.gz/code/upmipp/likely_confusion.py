import os
import torch
import time
from collections import namedtuple

from upmipp.utils import emb_text, get_markdown_pure_content
from upmipp.typosquat import run_test

meaningless_subdirs = ['data', 'src', 'main', 'tests', 'test', 'docs']

# parse meta indicators from projects
def parse_meta_from_projs(proj_root_dir:str):
    # what kinds of metadata needed
    metadata = {'readme':None, 'sub_dir_names':[]}

    # most cases project-content nested in a extract dir
    sub_nodes = list(os.scandir(proj_root_dir))
    if len(sub_nodes) == 1 and sub_nodes[0].is_dir():
        proj_root_dir = sub_nodes[0].path
    
    # for each 
    for sub_node in os.scandir(proj_root_dir):
        if sub_node.name.startswith('README'):
            # whether this is a directory or a file
            if sub_node.is_file():
                try:
                    with open(sub_node.path, 'r', encoding='utf-8-sig') as f:
                        metadata['readme'] = f.read()
                except UnicodeDecodeError:
                    pass
            elif sub_node.is_dir():
                readme_file = os.path.join(sub_node.path, 'README.md')
                if os.path.exists(readme_file):
                    with open(readme_file, 'r', encoding='utf-8-sig') as f:
                        metadata['readme'] = f.read()
                
        elif sub_node.name == 'PKG-INFO':
            pass
        elif sub_node.is_dir() and \
            not sub_node.name.endswith('.egg-info') and \
            not sub_node.name.endswith('.dist-info'):
            if sub_node.name not in meaningless_subdirs:
                metadata['sub_dir_names'].append(sub_node.name)
    
    return metadata

# find potential squatters
codequatters_by_name_cache = {}
def get_likely_codequatters_by_name(names:list, pkg_name_list:set):
    _key = '#'.join(names)
    if _key in codequatters_by_name_cache:
        return codequatters_by_name_cache[_key]

    quatters = []
    for name in names:
        if name in pkg_name_list:
            quatters.append(name)
        else:
            quatters.extend(run_test(name, pkg_name_list))
    
    codequatters_by_name_cache[_key] = quatters
    return quatters

codequatters_by_readme_cache = {}
def get_likely_codequatters_by_readme(readme_md_text:str, 
                                      readme_embeddings, 
                                      pkg_list_with_readme,
                                      topk:int,
                                      similarity_threshold:float,
                                      md_embedding_vector = None):
    if readme_md_text in codequatters_by_readme_cache:
        return codequatters_by_readme_cache[readme_md_text]

    start = time.time()
    md_pure_text = get_markdown_pure_content(readme_md_text)
    tick_1 = time.time()

    if md_embedding_vector is None:
        md_embedding_vector = emb_text(md_pure_text)

    tick_2 = time.time()
    cosine_similarities = torch.cosine_similarity(md_embedding_vector, readme_embeddings, dim=1)
    tick_3 = time.time()
    cosine_similarities_numpy = cosine_similarities.cpu().numpy()
    tick_4 = time.time()
    sorted_idxs = cosine_similarities.argsort(descending=True)
    tick_5 = time.time()
    sorted_idxs_numpy = sorted_idxs.cpu().numpy()
    tick_6 = time.time()

    ranked_pkgs, ranked_scores = [], []
    for i in range(topk):
        idx = sorted_idxs_numpy[i]
        similarity_score = cosine_similarities_numpy[idx]
        if similarity_threshold:
            if similarity_score >= similarity_threshold:
                ranked_pkgs.append(pkg_list_with_readme[idx])
                ranked_scores.append(similarity_score)
        else:
            ranked_pkgs.append(pkg_list_with_readme[idx])
            ranked_scores.append(similarity_score)

    end = time.time()
    
    # epslapes = [start, tick_1, tick_2, tick_3, tick_4, tick_5, tick_6, end]
    # for i in range(1, len(epslapes)):
    #     print(epslapes[i] - epslapes[i-1])

    print(f'Readme similarity used time: {end - start:.2f}')
    
    codequatters_by_readme_cache[readme_md_text] = (ranked_pkgs, ranked_scores)

    return ranked_pkgs, ranked_scores

# get likely confused names
def get_likely_code_squatters(name:str, 
                              proj_root_dir:str,
                              pkg_list:set,
                              readme_embeddings:torch.Tensor,
                              pkg_list_with_readme:set,
                              readme_top_n:int,
                              similarity_threshold:float,
                              norm_pkg_list:set = None
                             ):
    if name is None:
        name = proj_root_dir

    proj_name_squatters = get_likely_codequatters_by_name([name], pkg_list)
    # proj_name_squatters = sorted(proj_name_squatters, key=lambda x:len(x), reverse=True)

    proj_meta = parse_meta_from_projs(proj_root_dir)
    
    confused_names = [sdn for sdn in proj_meta['sub_dir_names'] if sdn != name]
    subdir_name_squatters = [cn for cn in confused_names if cn in pkg_list]
    
    # subdir_name_squatters = get_likely_codequatters_by_name(confused_names, pkg_list)
    # subdir_name_squatters = sorted(subdir_name_squatters, key=lambda x:len(x), reverse=True)

    readme_squatters, readme_similarities = [], []
    if proj_meta['readme']:
        readme_squatters, readme_similarities = \
            get_likely_codequatters_by_readme(
                                                proj_meta['readme'],
                                                readme_embeddings,
                                                pkg_list_with_readme,
                                                readme_top_n,
                                                similarity_threshold
                                             )
        
    return proj_name_squatters, subdir_name_squatters, readme_squatters, readme_similarities

# rank the squatter result by the priority scores
def rank(proj_name_squatters,
         subdir_name_squatters,
         readme_squatters):
        
    quatter_scores = {}
    for s in proj_name_squatters:
        quatter_scores[s] = 2
    
    for s in subdir_name_squatters:
        if s in quatter_scores:
            quatter_scores[s] += 3
        else:
            quatter_scores[s] = 3
    
    for s in readme_squatters:
        if s in quatter_scores:
            quatter_scores[s] += 4
        else:
            quatter_scores[s] = 4

    ranked_squatters = list(sorted(quatter_scores.items(), key=lambda x:x[1], reverse=True))
    ranked_squatters = {k: v for k, v in ranked_squatters}
    return ranked_squatters

# get likely confused names
def get_likely_code_squatters_new(name:str,
                                  proj_meta,
                                  similarity_vector:torch.Tensor,
                                  pkg_list:set,
                                  pkg_list_with_readme:set,
                                  readme_top_n:int,
                                  similarity_threshold:float,
                                  norm_pkg_list:set = None
                                 ):
    proj_name_squatters = get_likely_codequatters_by_name([name], pkg_list)
    
    confused_names = [sdn for sdn in proj_meta['sub_dir_names'] if sdn != name]
    subdir_name_squatters = [cn for cn in confused_names if cn in pkg_list]

    readme_squatters, readme_similarities = [], []

    if similarity_vector is not None:
        sorted_idxs = similarity_vector.argsort(descending=True)
        sorted_idxs_numpy = sorted_idxs.cpu().numpy()

        for i in range(readme_top_n):
            idx = sorted_idxs_numpy[i]
            similarity_score = similarity_vector[idx].item()
            if similarity_threshold:
                if similarity_score >= similarity_threshold:
                    readme_squatters.append(pkg_list_with_readme[idx])
                    readme_similarities.append(similarity_score)
            else:
                readme_squatters.append(pkg_list_with_readme[idx])
                readme_similarities.append(similarity_score)
        
    return proj_name_squatters, subdir_name_squatters, readme_squatters, readme_similarities