'''
pypi_pkg
'''
import time
import requests
from requests.exceptions import RequestException
from bs4 import BeautifulSoup, FeatureNotFound
import csv
import itertools
import json
import os
import traceback

from .utils import download_file_from_url, extract_archive, download_file_from_urls_async,\
                    download_file_from_urls_fast

def _print_msg(s:str):
    print(s, end='\n')
logger = _print_msg

def get_pypi_all_pkg_list():
    start = time.time()

    url = "https://pypi.org/simple/"
    pkg_list = []
    try_times = 10
    while try_times > 0:
        try:
            response = requests.get(url)
            soup = BeautifulSoup(response.content, 'html.parser')
            for link in soup.find_all('a'):
                pkg_list.append(link.text.strip())
            break
        except RequestException:
            try_times -= 1
            continue
        except FeatureNotFound:
            raise
        except:
            raise
        
    end = time.time()
    logger(f'Total {len(pkg_list)} packages in PyPI. Used time: {(end - start):.1f}s')
    return pkg_list

def save_pypi_all_pkgs_snapshot(save_path:str):
    pkg_list = get_pypi_all_pkg_list()
    pkg_list = [[pn] for pn in pkg_list]
    with open(save_path, 'w', encoding='utf-8-sig') as f:
        csv_writer = csv.writer(f)
        csv_writer.writerows(pkg_list)

def read_pypi_all_pkgs(snapshot_path:str) -> list:
    with open(snapshot_path, 'r', encoding='utf-8-sig') as f:
        csv_reader = csv.reader(f)
        all_pkgs = list(csv_reader)
    return list(itertools.chain(*all_pkgs))

def get_pkg_downloads_info(pkg_name:str):
    pypistat_api_url = "https://pypistats.org/api/packages/%s/recent" % pkg_name
    try:
        req_start = time.time()
        response = requests.get(pypistat_api_url, params={'period':'week'})
        req_end = time.time()
        return response.json(), round(req_end - req_start, 2)
    except:
        return None, None

# select partial release versions
def sample_versions(vers:list):
    major_minor = set()
    partial_vers = []
    for ver in vers:
        if '.' in ver:
            _major = ver.split('.')[0]
            _minor = ver.split('.')[1]
            _major_minor = '.'.join([_major, _minor])
            if _major_minor not in major_minor:
                partial_vers.append(ver)
                major_minor.add(_major_minor)
        else:
            partial_vers.append(ver)
    return partial_vers

# download all the releases of the specified package, invoked in run.py
def download_package_releases_and_extract(pkg_name:str, 
                                          version:str|list,
                                          pkg_meta_save_dir:str,
                                          cache_dir:str,
                                          if_async:bool = False,
                                          if_sample_ver:bool = True
                                          ) -> list:
    with open(os.path.join(pkg_meta_save_dir,
                           pkg_name + '.json'), 
                           mode='r',
                           encoding='utf-8-sig') as f:
        pkg_meta = json.load(f)
    try:
        if version == 'all':
            all_versions = list(pkg_meta['releases'].keys())
        else:
            assert version in pkg_meta['releases']
            all_versions = [version]
    except KeyError:
        print(f'The key `releases` is not in {pkg_name} meta. May the {pkg_name} have no releases yet?')
        return None
    except AssertionError:
        print(f'{pkg_name} has no version named {version}.')
        return None
    
    extract_paths = []
    download_urls = []
    download_save_paths = []

    all_versions = [v for v in all_versions if len(pkg_meta['releases'][v]) > 0] # versions must have releases
    all_versions.reverse()
    
    # select partial versions of the 
    if if_sample_ver:
        all_versions = sample_versions(all_versions)

    for ver in all_versions:
        save_dir = os.path.join(cache_dir, pkg_name, ver)
        # extract_path = os.path.join(cache_dir, pkg_name, ver, f'{pkg_name}-{ver}')
        
        flag = False
        if os.path.exists(save_dir) and len(os.listdir(save_dir)) > 0:
            for node in os.scandir(save_dir):
                if node.is_dir() and not node.name.endswith('dist-info') and\
                    not node.name.endswith('egg-info'):
                    extract_paths.append({'name':pkg_name, 'version':ver, 'path':node.path})
                    flag = True
        if flag:
            continue
        
        fn, url = None, None
        for rle in pkg_meta['releases'][ver]:
            if not url:
                fn = rle['filename']
                url = rle['url']
            if rle['filename'].endswith('.tar.gz'):
                fn = rle['filename']
                url = rle['url']
                break

        # save the download urls and file-save paths into list
        download_urls.append(url)
        
        os.makedirs(save_dir, exist_ok=True) # may raise OSError
        save_file_abs_path = os.path.join(save_dir, fn)
        download_save_paths.append(save_file_abs_path)

    if not if_async:
        for url, file_save_path, ver in zip(download_urls, download_save_paths, all_versions):
            status = download_file_from_url(url, file_save_path)
            if not status:
                print(f'Download failure for {pkg_name} {ver} from\n url: {url}')
            else:   # Download success
                try:
                    save_dir = os.path.dirname(file_save_path)
                    extract_archive(file_save_path, save_dir) # may encounter an exception
                    for node in os.scandir(save_dir):
                        if node.is_dir():
                            extract_paths.append({'name':pkg_name, 'version':ver, 'path':node.path})
                            break
                except Exception as e:
                    print(f'Download {file_save_path} not extracted in {save_dir}: \n')
                    traceback.print_exc()
                    print('=' * 100)
                    print(file_save_path, pkg_name, ver)
    else: # the async version to download
        # if len(download_urls) > 0:
        #     from pprint import pprint
        #     pprint(download_urls)
        #     print('package_name, download_urls_count')
        #     print(pkg_name, len(download_urls))
        #     for du in download_urls:
        #         res = requests.get(du)
        #         print(f'{res.status_code} download url:\n {du}')
        #     exit()

        download_file_from_urls_fast(download_urls, download_save_paths, all_versions, pkg_name)
        for file_save_path in download_save_paths:
            if not os.path.exists(file_save_path):
                print(f'{file_save_path} does not exists!')
                continue
            else:
                try:
                    save_dir = os.path.dirname(file_save_path)
                    extract_archive(file_save_path, save_dir) # may encounter an exception
                    for node in os.scandir(save_dir):
                        if node.is_dir():
                            extract_paths.append({'name':pkg_name, 'version':ver, 'path':node.path})
                            break
                except Exception as e:
                    print(f'Download {file_save_path} not extracted in {save_dir}: \n')
                    traceback.print_exc()
                    

    return extract_paths

# download benign package releases with specified versions from PyPI registry
def download_package_releases_and_extract_deprecated(pkg_name:str, 
                                                    version:str|list,
                                                    pkg_meta_save_dir:str,
                                                    cache_dir:str
                                                    ) -> list:
    with open(os.path.join(pkg_meta_save_dir, pkg_name + '.json'), mode='r', encoding='utf-8-sig') as f:
        pkg_meta = json.load(f)
    
    select_version = None
    try:
        if version in pkg_meta['releases']\
            and len(pkg_meta['releases'][version]) > 0: # may raise KeyError exception
            select_version = version
        else:
            all_vers = list(pkg_meta['releases'].keys())
            all_vers = [av for av in all_vers if len(pkg_meta['releases'][av]) > 0]
            if len(all_vers) <= 0:
                return None
            try:
                all_vers_int = [int(av.replace('.', '')) for av in all_vers]
            except ValueError:
                select_version = all_vers[len(all_vers)//2]
            else:
                min_gap, min_idx = None, None
                try:
                    ver_int = int(version.replace('.', ''))
                except Exception:
                    select_version = all_vers[len(all_vers)//2]
                else:    
                    for i in range(len(all_vers_int)):
                        if min_gap is None:
                            min_gap = abs(ver_int - all_vers_int[i])
                            min_idx = i
                        else:
                            if min_gap > abs(ver_int - all_vers_int[i]):
                                min_gap = abs(ver_int - all_vers_int[i])
                                min_idx = i
                    # the final selected version
                    select_version = all_vers[min_idx]
    except KeyError:
        return None

    # the target exist in the cache dir
    if os.path.exists(os.path.join(cache_dir, pkg_name, select_version, f'{pkg_name}-{select_version}')):
        return os.path.join(cache_dir, pkg_name, select_version, f'{pkg_name}-{select_version}')
    
    fn, download_url = None, None
    for rle in pkg_meta['releases'][select_version]:
        if not download_url:
            fn = rle['filename']
            download_url = rle['url']
        if rle['filename'].endswith('.tar.gz'):
            fn = rle['filename']
            download_url = rle['url']
            break
    
    # if not download_url:
    #     print(f'No find version: {select_version} for package: {pkg_name}')
    #     return None
    
    save_dir = os.path.join(cache_dir, pkg_name, select_version)
    os.makedirs(save_dir, exist_ok=True)

    save_file_name = os.path.join(save_dir, fn)
    status = download_file_from_url(download_url, save_file_name)
    if not status:
        print(f'Download failure for {pkg_name}-{select_version} from\n url: {download_url}')
        return None
    
    extract_archive(save_file_name, save_dir)
    return save_dir
