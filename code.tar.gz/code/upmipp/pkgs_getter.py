'''
pkgs_getter
'''
import os
from pathlib import Path
import json
from typing import List, Dict
from pprint import pprint
from dataclasses import dataclass, field
from datetime import datetime
import csv

from regex import P
from tqdm import tqdm

def _print_msg(s:str):
    print(s, end='\n')
logger = _print_msg

import zipfile
import tarsafe
ret_code_explain = {
    0:'Success',
    1:'Unsupported archive file type',
    2:'TarSafeException',
    3:'Unknown error'
}
def extract_archive(source_archive: str, target_directory: str) -> None:
    try:
        if source_archive.endswith('.tar.gz') or \
            source_archive.endswith('.tgz'):
            tarsafe.open(source_archive).extractall(target_directory)
            return 0
        elif source_archive.endswith('.zip') or \
            source_archive.endswith('.whl') or \
            source_archive.endswith('.egg'):
            with zipfile.ZipFile(source_archive, 'r') as zip:
                # for file in zip.namelist():
                #     # Note: zip.extract cleans up any malicious file name such as directory traversal attempts
                #     # This is not the case of zipfile.extractall
                #     zip.extract(file, path=os.path.join(target_directory, file))
                zip.extractall(target_directory)
            return 0
        else:
            logger("Unsupported archive type: " + source_archive)
            return 1
    except tarsafe.tarsafe.TarSafeException:
        logger('tarsafe extract encounter an exception: ')
        logger('\t\t', source_archive, target_directory)
        return 2
    except Exception:
        logger('Extract encounter unknown exception:')
        logger('\t\t', source_archive, target_directory)
        import traceback
        traceback.print_stack()
        return 3
        
def extract_batch(src_pkgs:List[str], tgt_paths:List[str]):
    error_info = []
    for src, tgt in tqdm(zip(src_pkgs, tgt_paths)):
        if not os.path.exists(tgt) or len(os.listdir(tgt)) == 0:
            os.makedirs(tgt, exist_ok=True)
            ret_code = extract_archive(src, tgt)
            if ret_code > 0:
                error_info.append({'src_package':src, 'error_reason':ret_code_explain[ret_code]})
    return error_info

def satisfy_time_range(
                        t1:str, 
                        start_time:str = '2023-12-01T00:00:00', 
                        end_time:str = '2023-12-15T00:00:00'
                      ):
    if start_time is None or end_time is None:
        return True
    time_format = r"%Y-%m-%dT%H-%M-%S"
    t1_obj = datetime.strptime(t1, time_format)
    start_obj = datetime.strptime(start_time, time_format)
    end_obj = datetime.strptime(end_time, time_format)
    return t1_obj >= start_obj and t1_obj <= end_obj

@dataclass
class PackageInfo:
    name:str = None,
    version:str = None,
    local_path:str = None,
    meta_path:str = None,
    extract_path:str = None,
    source:str = None,      # the source where the package comes from
    
    label:str|List[str] = None,
    consistent:bool|str = None # if it is consistent or inconsistent confusion

    def __str__(self) -> str:
        return json.dumps(self.__dict__)
    
    def __repr__(self) -> str:
        return self.__str__()
    
    def to_dict(self) -> Dict:
        return self.__dict__

def get_new_pkgs(base_dir:str, 
                 date_range:tuple, 
                 extract_mode:bool = False) -> List[PackageInfo]:
    # select the satisfied time range dirs
    sub_dirs = filter(lambda x: x.is_dir() and \
                      satisfy_time_range(x.name, date_range[0], date_range[1]), 
                      os.scandir(base_dir))
    
    # sort by datetime
    def key_time(d):
        time_format = r"%Y-%m-%dT%H-%M-%S"
        t_obj = datetime.strptime(d.name, time_format)
        return t_obj
    sub_dirs = sorted(sub_dirs, key=key_time)

    new_pkgs = []       # new packages with info
    src_paths = []
    ert_paths = []      # extract paths
    unique_pkgs = set() # for filter purpose

    for sd in sub_dirs:
        sd_path = Path(sd.path)
        sd_newest_package_path:Path = sd_path / 'packages/newest_uploaded'

        # each sub package dir
        newest_packages = [p.name for p in sd_newest_package_path.iterdir() if p.is_dir()]
        for npn in newest_packages:     # np := newest package name
            if npn in unique_pkgs:      # npn is a duplicated package
                continue
            
            # the newest package path
            np_path:Path = sd_newest_package_path / npn

            # all the versions of the package
            versions = [p.name for p in np_path.iterdir() if p.is_dir()]
            
            final = None
            fn_path = None
            extract_path = None
            version = None
            for v in versions: # for each version of the package
                v_path:Path = np_path / v

                # all the archive names of the version of the package
                fns = [p.name for p in v_path.iterdir() if p.is_file()]

                for fn in fns: # for each archive names
                    if fn.endswith('.tar.gz'):
                        final = fn
                        break
                    if final is None:
                        final = fn
                
                if final is not None:
                    fn_path = v_path / final
                    extract_path = v_path / 'source'
                    version = v
                    break

            if extract_path is not None:    # npn has empty releases
                # if not extract_mode:
                #     # add the packages to be detected: (package name, package version, package path)
                #     if extract_path.exists() and len(os.listdir(str(extract_path.resolve()))) > 0:
                #         new_pkgs.append((npn, v, str(extract_path.resolve())))
                # else:
                #     new_pkgs.append(str(fn_path.resolve()))
                new_pkgs.append(PackageInfo(
                                            name=npn, version=version, local_path=str(fn_path.resolve()),
                                            meta_path=os.path.join(str(np_path.resolve()), 'meta.json'),
                                            extract_path=str(extract_path.resolve()), source='pypi.org'
                                        )
                                )
                if not extract_path.exists():
                    src_paths.append(str(fn_path.resolve()))
                    ert_paths.append(str(extract_path.resolve()))
            
            unique_pkgs.add(npn)
    
    if extract_mode:
        # src_paths = list(map(lambda x:x.local_path, new_pkgs))
        # ert_paths = list(map(lambda x:x.extract_path, new_pkgs))
        err_info = extract_batch(src_paths, ert_paths)
        logger(f'Extraction errors: {err_info}')
    else:
        err_info = {}

    return new_pkgs, err_info
 