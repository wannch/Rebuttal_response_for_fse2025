'''
detect typosquatting packages
'''

import jellyfish
import Levenshtein

import itertools

edit_distance_cache = {} # cache result
def edit_distance_attack(pkg_name:str, package_list, threshold:int = 2):
    if pkg_name in edit_distance_cache:
        return edit_distance_cache[pkg_name]

    quatters = {i:[] for i in range(1, threshold+1)}
    for tgt in package_list:
        dis = Levenshtein.distance(pkg_name, tgt)
        if dis <= threshold:
            quatters[dis].append(tgt)

    candidates = []
    for i in range(1, threshold+1):
        candidates.extend(quatters[i])
    
    edit_distance_cache[pkg_name] = (quatters[1], quatters[2])
    
    # return candidates
    return quatters[1], quatters[2]

order_attack_cache = {} # cache result
def order_attack_screen(pkg_name:str, package_list):
    # Check if there is only one total dash or underscore
    # TODO: Consider dealing with other cases (e.g. >=2 dashes)
    if pkg_name in order_attack_cache:
        return order_attack_cache[pkg_name]

    squatters = []
    if pkg_name.count("-") + pkg_name.count("_") == 1:
        if pkg_name.count("-") == 1:
            pkg_name_list = pkg_name.split("-")
            reversed_name = pkg_name_list[1] + "-" + pkg_name_list[0]
            switch_symbol = pkg_name_list[0] + "_" + pkg_name_list[1]
            switch_symbol_reversed = pkg_name_list[1] + "_" + pkg_name_list[0]
        else:
            pkg_name_list = pkg_name.split("_")
            reversed_name = pkg_name_list[1] + "_" + pkg_name_list[0]
            switch_symbol = pkg_name_list[0] + "-" + pkg_name_list[1]
            switch_symbol_reversed = pkg_name_list[1] + "-" + pkg_name_list[0]
        # Check if each attack is contained in the full package list
        for attack in [reversed_name, switch_symbol, switch_symbol_reversed]:
            if attack in package_list:
                squatters.append(attack)
    
    # cache the result
    order_attack_cache[pkg_name] = squatters

    return squatters

# this function costs major time of the test pipline, however, squatters identified
# by this function is not apparently similar to the original package name, so
# this function should be an optional one when practically used.
def homophone_attack_screen(package_of_interest, package_list):
    """Find packages that prey on homophone confusion.

    This screen checks for attacks that prey on user confusion
    related to homophones. For instance, 'klumpz' vs. 'clumps'.
    This function helps find confusion attacks, rather than
    misspelling attacks.

    Args:
        package (str): package name on which to perform comparison
        all_packages (list): list of all package names

    Returns:
        list: potential typosquatting packages
    """
    # Empty list to store similar package names
    homophone_package_names = []

    # Calculate metaphone code for package of interest, only once
    package_of_interest_metaphone = set()
    package_of_interest_metaphone.add(jellyfish.metaphone(package_of_interest))
    # package_of_interest_metaphone.add(jellyfish.soundex(package_of_interest))
    # package_of_interest_metaphone.add(jellyfish.nysiis(package_of_interest))
    # package_of_interest_metaphone.add(jellyfish.match_rating_codex(package_of_interest))

    # Loop thru all package names
    for package in package_list:

        # Skip if the package is the package of interest
        if package == package_of_interest:
            continue

        # Compare package metaphone code to the metaphone code of the
        # package of interest
        if jellyfish.metaphone(package) in package_of_interest_metaphone:
            homophone_package_names.append(package)
        # elif jellyfish.soundex(package) in package_of_interest_metaphone:
        #     homophone_package_names.append(package)
        # elif jellyfish.nysiis(package) in package_of_interest_metaphone:
        #     homophone_package_names.append(package)
        # elif jellyfish.match_rating_codex(package) in package_of_interest_metaphone:
        #     homophone_package_names.append(package)

    return homophone_package_names

import re
from itertools import groupby, permutations

delimiter_regex = re.compile('[\-|\.|_]')
delimiters = ['', '.', '-', '_']

version_number_regex = re.compile('^(.*?)[\.|\-|_]?\d$')

typos = {
    '1': ['2', 'q', 'i', 'l'],
    '2': ['1', 'q', 'w', '3'],
    '3': ['2', 'w', 'e', '4'],
    '4': ['3', 'e', 'r', '5'],
    '5': ['4', 'r', 't', '6', 's'],
    '6': ['5', 't', 'y', '7'],
    '7': ['6', 'y', 'u', '8'],
    '8': ['7', 'u', 'i', '9'],
    '9': ['8', 'i', 'o', '0'],
    '0': ['9', 'o', 'p', '-'],
    '-': ['_', '0', 'p', '.', ''],
    '_': ['-', '0', 'p', '.', ''],
    'q': ['1', '2', 'w', 'a'],
    'w': ['2', '3', 'e', 's', 'a', 'q', 'vv'],
    'e': ['3', '4', 'r', 'd', 's', 'w'],
    'r': ['4', '5', 't', 'f', 'd', 'e'],
    't': ['5', '6', 'y', 'g', 'f', 'r'],
    'y': ['6', '7', 'u', 'h', 't', 'i'],
    'u': ['7', '8', 'i', 'j', 'y', 'v'],
    'i': ['1', '8', '9', 'o', 'l', 'k', 'j', 'u', 'y'],
    'o': ['9', '0', 'p', 'l', 'i'],
    'p': ['0', '-', 'o'],
    'a': ['q', 'w', 's', 'z'],
    's': ['w', 'd', 'x', 'z', 'a', '5'],
    'd': ['e', 'r', 'f', 'c', 'x', 's'],
    'f': ['r', 'g', 'v', 'c', 'd'],
    'g': ['t', 'h', 'b', 'v', 'f'],
    'h': ['y', 'j', 'n', 'b', 'g'],
    'j': ['u', 'i', 'k', 'm', 'n', 'h'],
    'k': ['i', 'o', 'l', 'm', 'j'],
    'l': ['i', 'o', 'p', 'k', '1'],
    'z': ['a', 's', 'x'],
    'x': ['z', 's', 'd', 'c'],
    'c': ['x', 'd', 'f', 'v'],
    'v': ['c', 'f', 'g', 'b', 'u'],
    'b': ['v', 'g', 'h', 'n'],
    'n': ['b', 'h', 'j', 'm'],
    'm': ['n', 'j', 'k', 'rn'],
    '.': ['-', '_', '']
}

common_prefix_suffixs = ['python3', 'python2', 'python', 'py3', 'py2', 'py', 'Python3', 'Python2', 'Python', 
                         'Py2', 'Py3', 'Py', 'module',
                         'my', 'new', 'dev', '-', '_', '.']
from string import digits
leading_chars = set(digits) | set('.-_')

def _judge_prefix_suffix(name:str, package_list):
    res = []
    # the missing prefix/suffix
    for c in common_prefix_suffixs:
        if c + name in package_list:
            res.append(c + name)
        if name + c in package_list:
            res.append(name + c)
        if c + '-' + name in package_list:
            res.append(c + '-' + name)
        if name + '-' + c in package_list:
            res.append(name + '-' + c)
        if c + '_' + name in package_list:
            res.append(c + '_' + name)
        if name + '_' + c in package_list:
            res.append(name + '_' + c)
    return res

# check if two packages have the same name given the python module naming conventions
def same_name(p1, p2):
    return re.sub(r'[-_.]+', '-', p1).lower() == re.sub(r'[-_.]+', '-', p2).lower()

# 'reeaaaccct' => 'react'
repeated_characters_cache = {}
def repeated_characters(package_name:str, package_list):
    if package_name in repeated_characters_cache:
        return repeated_characters_cache[package_name]

    s = ''.join([i[0] for i in groupby(package_name)])
    
    if s in package_list:
        repeated_characters_cache[package_name] = [s]
        return [s]

    repeated_characters_cache[package_name] = []
    return []

# 'event-streaem' => 'event-stream'
# 'event-stream' => 'event-strem'
omitted_chars_cache = {}
def omitted_chars(package_name, package_list):
    if package_name in omitted_chars_cache:
        return omitted_chars_cache[package_name]

    candidates = []

    if len(package_name) < 4:
        omitted_chars_cache[package_name] = candidates
        return candidates

    for i in range(len(package_name)):
        s = package_name[:i] + package_name[(i + 1):]

        if s in package_list:
            candidates.append(s)

    omitted_chars_cache[package_name] = candidates
    return candidates

# 'loadsh' => 'lodash'
swapped_characters_cache = {}
def swapped_characters(package_name, package_list):
    if package_name in swapped_characters_cache:
        return swapped_characters_cache[package_name]
    
    candidates = []

    for i in range(len(package_name) - 1):
        a = list(package_name)
        t = a[i]
        a[i] = a[i + 1]
        a[i + 1] = t
        s = ''.join(a)

        if s in package_list:
            candidates.append(s)

        candidates.extend(_judge_prefix_suffix(s, package_list))

    swapped_characters_cache[package_name] = candidates
    return candidates

# 'stream-event' => 'event-stream'
# 'event.stream' => 'event-stream'
# 'de-bug' => 'debug'
swapped_words_cache = {}
def swapped_words(package_name, package_list):
    if package_name in swapped_words_cache:
        return swapped_words_cache[package_name]
    
    candidates = []

    if delimiter_regex.search(package_name) is not None:
        tokens = delimiter_regex.sub(' ', package_name).split()

        for p in permutations(tokens):
            for d in delimiters:
                s = d.join(p)

                if s in package_list:
                    candidates.append(s)

    swapped_words_cache[package_name] = candidates
    return candidates

# '1odash' => 'lodash'
# 'teqeusts' => 'requests']
common_typos_cache = {}
def common_typos(package_name, package_list):
    if package_name in common_typos_cache:
        return common_typos_cache[package_name]

    candidates = []

    for i, c in enumerate(package_name):
        if c in typos:
            for t in typos[c]:
                s = list(package_name)
                s[i] = t
                s = ''.join(s)

                if s in package_list:
                    candidates.append(s)

    common_typos_cache[package_name] = candidates
    return candidates

# 'react-2' => 'react'
# 'react2' => 'react'
version_numbers_cache = {}
def version_numbers(package_name, package_list):
    if package_name in version_numbers_cache:
        return version_numbers_cache[package_name]

    candidates = []
    m = version_number_regex.match(package_name)

    if m is not None:
        s = m.group(1)

        # print("In version numbers: ", s)

        if s in package_list:
            candidates = [s]

    version_numbers_cache[package_name] = candidates
    return candidates

# self-defined combo-squatters detection method
combosquatters_attack_cache = {}
def combosquatters_attack(pkg_name:str, package_list, lower_package_list = None):
    if pkg_name in combosquatters_attack_cache:
        return combosquatters_attack_cache[pkg_name]

    candidates = []
    if len(set('-_.') & set(pkg_name)) > 0:
        pkg_name_parts = pkg_name.replace('-', ' ').replace('_', ' ').replace('.', ' ').split()
        pkg_name_parts = sorted(pkg_name_parts, key=lambda x:len(x), reverse=True)
        i = 0
        for part in pkg_name_parts:
            if part not in package_list:
                break
            i += 1
        if i >= len(pkg_name_parts):
            candidates.extend(pkg_name_parts)
    else:
        for i in range(1, len(pkg_name) + 1):
            if pkg_name[:i] in package_list and pkg_name[i:] in package_list:
                if i <= len(pkg_name):
                    candidates.append(pkg_name[i:])
                    candidates.append(pkg_name[:i])
                else:
                    candidates.append(pkg_name[:i])
                    candidates.append(pkg_name[i:])
                break
    
    combosquatters_attack_cache[pkg_name] = candidates

    return candidates

additional_prefix_suffix_cache = {}
def additional_prefix_suffix_attack(pkg_name:str, package_list):
    if pkg_name in additional_prefix_suffix_cache:
        return additional_prefix_suffix_cache[pkg_name]

    candidates = []

    # remove leading chars
    left, right = 0, len(pkg_name) - 1
    while left < len(pkg_name) and pkg_name[left] in leading_chars:
        left += 1
    while right >= left and pkg_name[right] in leading_chars:
        right -= 1
    s = pkg_name[left: right + 1]
    
    def _has_common_prefix_suffix(s:str):
        for c in common_prefix_suffixs:
            if s.startswith(c) or s.endswith(c):
                return c
        return None
    
    ps = _has_common_prefix_suffix(s)
    while ps:
        s = s.removeprefix(ps)
        s = s.removesuffix(ps)
        if s in package_list:
            candidates.append(s)
        ps = _has_common_prefix_suffix(s)
    
    # if the core is in the benign packages
    if s in package_list:
        candidates.append(s)
    
    additional_prefix_suffix_cache[pkg_name] = candidates
    
    return candidates

removed_prefix_suffix_cache = {}
def removed_prefix_suffix_attack(pkg_name:str, package_list):
    if pkg_name in removed_prefix_suffix_cache:
        return removed_prefix_suffix_cache[pkg_name]
    
    candidates = []
    
    candidates.extend(_judge_prefix_suffix(pkg_name, package_list))

    removed_prefix_suffix_cache[pkg_name] = candidates
    return candidates

run_test_cache = {}
def run_test(package_name:str, 
             all_packages,
             lower_all_pacakges = None):
    if package_name in run_test_cache:
        return run_test_cache[package_name]
    
    ed_1_squatters, ed_2_squatters = edit_distance_attack(package_name, package_list=all_packages)
    package_name_len = len(package_name)
    package_name_chars = set(package_name)
    ed_2_squatters = filter(lambda x: len(x) == package_name_len, ed_2_squatters)
    ed_2_squatters = sorted(ed_2_squatters, key=lambda x: len(package_name_chars & set(x)), reverse=True)
 
    results = [
        ed_1_squatters,
        order_attack_screen(package_name,package_list=all_packages),
        swapped_characters(package_name, package_list=all_packages),
        omitted_chars(package_name, package_list=all_packages),
        common_typos(package_name, package_list=all_packages),
        swapped_words(package_name, package_list=all_packages),
        additional_prefix_suffix_attack(package_name, package_list=all_packages),
        removed_prefix_suffix_attack(package_name, package_list=all_packages),
        combosquatters_attack(package_name, package_list=all_packages),
        # homophone_attack_screen(package_name, package_list=all_packages),
        repeated_characters(package_name, package_list=all_packages),
        version_numbers(package_name, package_list=all_packages),
        ed_2_squatters
    ]

    # flatten
    # r = set(itertools.chain(*results))
    # r =  list(r)
    r, s = [], set()
    results = itertools.chain(*results)
    for res in results:
        if res not in s:
            r.append(res)
            s.add(res)
    
    run_test_cache[package_name] = r 
    return r

