'''
scrapy the READMEs of all the pypi projects.
'''

from upmipp.pypi_pkg import read_pypi_all_pkgs
from utils import get_markdown_pure_content

from sentence_transformers import SentenceTransformer
import json
import os
import torch
import itertools
import csv
from tqdm import tqdm, trange

def _read_pypi_pkg_list(file:str):
    with open(file, 'r') as f:
        csv_reader = csv.reader(f)
        all_pkgs = list(csv_reader)
    return list(itertools.chain(*all_pkgs))

def emb_text(texts:list):
    model = SentenceTransformer('all-MiniLM-L6-v2', device='cuda:0')
    text_embeddings = \
        model.encode(texts,
                     batch_size=1024, 
                     show_progress_bar=True,
                     convert_to_numpy=False,
                     convert_to_tensor=True,
                     device='cuda:0')
    return text_embeddings

def process_readme_into_pure_text(pkg_list_file:str, 
                                  pkg_meta_dir:str, 
                                  pure_text_save_dir:str = './readme_pure_texts'):
    pkg_list = _read_pypi_pkg_list(pkg_list_file)
    print(f'Process total {len(pkg_list)} packages.')

    for pn in tqdm(pkg_list):
        with open(os.path.join(pkg_meta_dir, pn + '.json'), mode='r', encoding='utf-8-sig') as f:
            pn_meta = json.load(f)
        desc = pn_meta['info']['description']
        pure = get_markdown_pure_content(desc)
        
        with open(os.path.join(pure_text_save_dir, pn + '.txt'), 'w') as fout:
            fout.write(pure)
            
def emb_batch_readme(pkg_list:list, pure_text_save_dir:str, mem_batch:int = 10000):
    total_size = len(pkg_list)
    
    all_embeddings = []
    for i in trange(0, total_size, mem_batch):
        batch_pkgs = pkg_list[i:i+mem_batch]
        batch_readme_pure = []

        for pn in batch_pkgs:
            pn_meta = os.path.join(pure_text_save_dir, pn + '.txt')
            with open(pn_meta, 'r', encoding='utf-8-sig') as f:
                readme_text = f.read()
            batch_readme_pure.append(readme_text)
        
        # embed batch readmes
        batch_embeddings = emb_text(batch_readme_pure)
        all_embeddings.append(batch_embeddings)

    return all_embeddings

def _load_json_file(file:str):
    with open(file, 'r') as f:
        content = json.load(f)
    return content

def emb_pypi_project_readme(pkg_list_file:str, pure_text_save_dir:str, embedding_save_dir:str):
    pypi_projs = _read_pypi_pkg_list(pkg_list_file)
    
    readme_embeddings = emb_batch_readme(pypi_projs, pure_text_save_dir, mem_batch=10000)

    all_in_one_embeddings = torch.concat(readme_embeddings, dim=0)
    save_file = os.path.join(embedding_save_dir, 'pypi_project_readme_embbeding.pt')
    torch.save(all_in_one_embeddings, save_file)
