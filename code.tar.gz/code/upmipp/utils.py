import os
import time
import requests
import json
from pathlib import Path
import traceback

exclude_subdirs = [] # ['tests']
exclude_files = set() # set(['setup.py'])

# get all the satisfactory files
def get_all_files(d:str, ext:str = '.py'):
    py_files = []
    for root, dirs, files in os.walk(d):
        for file in files:
            if file.endswith(ext):
                py_files.append(os.path.join(root, file))
    
    return py_files

# get all the satisfactory file subpaths
def get_all_file_subpaths(d:str, sp:str, ext:str = '.py', excludes:list = set()):
    # root_name = os.path.basename(d.rstrip(os.sep))
    file_sub_paths = []
    for sub_node in os.scandir(d):
        if sub_node.is_dir():
            sub_dir_sp = sp + os.sep + sub_node.name
            file_sub_paths.extend(get_all_file_subpaths(sub_node.path, sub_dir_sp, ext, excludes))
        elif sub_node.is_file():
            if sub_node.name.endswith(ext) and sub_node.name not in excludes:
                file_sub_paths.append(sp + os.sep + sub_node.name)
    return file_sub_paths

# only return file names
def get_all_file_names(d:str, ext:str = '.py', excludes:list = exclude_files):
    py_file_names = []
    for root, dirs, files in os.walk(d):
        if os.path.basename(root) in exclude_subdirs:
            continue
        for file in files:
            if file.endswith(ext) and file not in excludes:
                py_file_names.append(file)
    
    return py_file_names

import zipfile
import tarsafe
def extract_archive(source_archive: str, target_directory: str) -> None:
    """
    safe_extract safely extracts archives to a target directory.

    This function does not clean up the original archive, and does not create the target directory if it does not exist.

    @param source_archive:      The archive to extract
    @param target_directory:    The directory where to extract the archive to
    @raise ValueError           If the archive type is unsupported
    """
    if source_archive.endswith('.tar.gz') or source_archive.endswith('.tgz') or source_archive.endswith('.tar.bz2'):
        tarsafe.open(source_archive).extractall(target_directory)
    elif source_archive.endswith('.zip') or source_archive.endswith('.whl') or source_archive.endswith('.egg'):
        with zipfile.ZipFile(source_archive, 'r') as zip:
            for file in zip.namelist():
                # Note: zip.extract cleans up any malicious file name such as directory traversal attempts
                # This is not the case of zipfile.extractall
                zip.extract(file, path=os.path.join(target_directory, file))
    else:
        
        raise ValueError("unsupported archive extension: " + source_archive)
    
def request_url(url:str):
    try:
        req_start = time.time()
        response = requests.get(url)
        req_end = time.time()
        return response.json(), round(req_end - req_start, 2)
    except:
        return None, None

def get_top_pypi_packages_30_days(cache:bool = True):
    top30, _ = request_url('https://hugovk.github.io/top-pypi-packages/top-pypi-packages-30-days.json')
    
    if cache:
        cache_file_name = top30['last_update'].replace(' ', '_') + '_30days.json'
        dir = Path(__file__).parent.parent.resolve().as_posix() + os.sep + 'resources'
        abs_cache_file_name = os.path.join(dir, cache_file_name)
        if not os.path.exists(abs_cache_file_name):
            with open(abs_cache_file_name, 'w') as f:
                json.dump(top30, f, indent=4)
    
    top_pypi_pkgs = list(map(lambda x:x['project'], top30['rows']))
    return top_pypi_pkgs

# download file from url and save into a file
def download_file_from_url(url:str, save:str):
    for _ in range(3):
        try:
            response = requests.get(url)
            if response.status_code == 200:
                with open(save, 'wb') as f:
                    f.write(response.content)
                return True
            else:
                continue
        except Exception:
            continue
    return False

import asyncio
import aiohttp
async def _download_from_site_async(url:str,
                                    save_path:str,
                                    version:str,
                                    name:str,
                                    session:aiohttp.ClientSession):
    try:
        async with session.get(url) as response:
            if response.status == 200:
                with open(save_path, 'wb') as f:
                    ctt = await response.read()
                    f.write(ctt)
            else:
                print(f'Request for {url} return {response.status} http code.')
    except ValueError:
        raise
    except Exception as e:
        traceback.print_exc()
        print(f'Download failure for {name} {version} from\n url: {url}')
        exit()

# a async version of the downloader
async def download_file_from_urls_async(urls:list, save_paths:list, versions:list, name:str):
    async with aiohttp.ClientSession() as session:
        tasks = []
        for url, save_path, ver in zip(urls, save_paths, versions):
            print(f'{url}, {save_path}, {ver}')
            task = asyncio.ensure_future( _download_from_site_async(url, save_path, ver, name, session) )
            tasks.append(task)
        await asyncio.gather(*tasks, return_exceptions=True)

# a fast version of the downloader
def download_file_from_urls_fast(urls:list, save_paths:list, versions:list, name:str):
    try:
        asyncio.get_event_loop().run_until_complete(download_file_from_urls_async(urls, save_paths, versions, name))
    except Exception as exc:
        print(f'Exception catched in download_file_from_urls_fast: ')
        exit()

from sentence_transformers import SentenceTransformer
def emb_text(s:str|list, batch_size:int = 1024):
    model = SentenceTransformer('your path of sentence-transformers_all-MiniLM-L6-v2', device='cuda:0')
    text_embeddings = \
        model.encode(
                        s,
                        batch_size=batch_size, 
                        show_progress_bar=True,
                        convert_to_numpy=False,
                        convert_to_tensor=True,
                        device='cuda:0'
                    )
    return text_embeddings

import torch
def load_embedding(file:str):
    return torch.load(file)

def _get_mem_size_of_tesnor(t:torch.Tensor):
    return t.element_size() * t.nelement() / 2**30
# cosine similarity between 
def calculate_similarity(a:torch.Tensor, b:torch.Tensor):
    start = time.perf_counter()
    # similarity_scores = torch.cosine_similarity(a, b, dim=1)
    # similarity_scores = torch.cosine_similarity(a.unsqueeze(1), b.unsqueeze(0), dim=2)
    mm_ab = torch.matmul(a, b.transpose(0, 1))
    mm_norm = torch.matmul(torch.norm(a, p=2, dim=1).unsqueeze(1), torch.norm(b, p=2, dim=1).unsqueeze(0))
    print(f'mm_ab size: {_get_mem_size_of_tesnor(mm_ab)}GB, mm_norm size: {_get_mem_size_of_tesnor(mm_norm)}GB')
    
    similarity_scores = mm_ab / mm_norm # This may raise "torch.cuda.OutOfMemoryError: CUDA out of memory"
    
    end = time.perf_counter()
    print(f'calculate_similarity costs time: {end - start:.2f}')
    return similarity_scores

# process markdown-style str
import markdown
from bs4 import BeautifulSoup
def get_markdown_pure_content(md_str:str):
    html = markdown.markdown(md_str)

    soup = BeautifulSoup(html, 'html.parser')
    plain_text = soup.get_text()
    
    return plain_text

import csv
import itertools
# read csv records from csv file
def read_csv_records(file:str):
    with open(file, 'r') as f:
        csv_reader = csv.reader(f)
        all_pkgs = list(csv_reader)
    return list(itertools.chain(*all_pkgs))
 
def test_get_all_file_subpaths():
    get_all_file_subpaths('', '')
    pass

def transform_to_hms(sec:int):
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec - h * 3600 - m * 60
    return f'{h}h{m}m{s}s'
