import os
import itertools
import string
from typing import List, Iterable, Dict, Set, Tuple
from pprint import pprint
import traceback
from upmipp import proj_diff

from .utils import get_all_files, get_all_file_names

def _read_text_file(file:str) -> str:
    try:
        with open(file, "r") as f:
            content = f.read()
    except UnicodeDecodeError as ude:
        print(f'UnicodeDecodeError file={file}')
        traceback.print_exc()
        return ''
    except FileNotFoundError:
        traceback.print_exc()
    return content

def _split_lines_non_empty(s:str, use_line_map:bool) -> Tuple:
    if not use_line_map:
        return [line for line in s.splitlines() if line.strip()], None

    new_line_nu = -1
    lines = []
    line_nu_map = {}
    for ori_line_nu, ori_line in enumerate(s.splitlines()):
        if ori_line.strip():
            new_line_nu += 1
            lines.append(ori_line)
            line_nu_map[new_line_nu] = ori_line_nu
    return lines, line_nu_map

import re
def _remove_whitespaces(s:str) -> List[str]:
    return re.sub(r'\s', '', s)

def _remove_comments(content:str) -> str:
    # currently not implemented
    return content

import hashlib
def _hash(s:bytes|str) -> str:
    if isinstance(s, str):
        s = s.encode('utf-8')
    sha256_hash = hashlib.sha256()
    sha256_hash.update(s)
    return sha256_hash.hexdigest()

from collections import namedtuple
FileDiffResult = namedtuple('FileDiffResult', ['file', 'benign_file', 'start_line', 'end_line', 'discrepency_code'])

# Parse files and its code 
def parse_files_from_proj(proj_path:str) -> Dict:
    proj_files = get_all_files(proj_path, ext='.py')    # traverse all the py files in the proj
    file_hash_and_line_map = {}
    for pf in proj_files:
        content = _read_text_file(pf)
        if not content.strip():
            continue

        file_content_hash = _hash(content)
        file_hash_and_line_map[file_content_hash] = {}
        file_hash_and_line_map[file_content_hash]['file'] = pf

        lines, _ = _split_lines_non_empty(content, use_line_map=False)
        file_hash_and_line_map[file_content_hash]['lines'] = lines 

    return file_hash_and_line_map

# Calculate code similarity between two projects
def diff_between_proj_map(detect_map:Dict, cand_map:Dict):
    detect_map_key_set = set(detect_map.keys())
    cand_map_key_set = set(cand_map.keys())
    # common files hashes/common files
    common_file_hashes = detect_map_key_set & cand_map_key_set
    
    common_line_total = sum([len(detect_map[cfh]['lines']) for cfh in common_file_hashes], 0)
    # the detect and cand do not have common file but may have common code in compromised source file
    
    # strip common files, only reserve UNIQUE files for the detect and cand project
    only_in_detect = detect_map_key_set - common_file_hashes
    only_in_cand = cand_map_key_set - common_file_hashes

    similar_file_pairs = []
    detect_only_files = []
    excluded_oics = set() # OIC should be excluded
    # each unique detect file hash
    for oid in only_in_detect:
        oid_lines_set = set(detect_map[oid]['lines'])
        max_common_line, max_oic_for_oid = 0, None
        
        # find the most similar candidate project
        for oic in only_in_cand:
            if oic in excluded_oics:
                continue
            oic_set = set(cand_map[oic]['lines'])
            common_line_count = len(oid_lines_set & oic_set)
            if common_line_count > max_common_line:
                max_common_line = common_line_count
                max_oic_for_oid = oic
        
        # already find the most similar OIC for OID, maybe they are compromised file each other
        if max_oic_for_oid:
            excluded_oics.add(max_oic_for_oid)
            common_line_total += max_common_line
            similar_file_pairs.append((oid, oic))
        # the file may be a discrepancy file or a normal unique file
        else:
            detect_only_files.append(oid)

    return {
        'common_line_total': common_line_total,
        'similar_file_pairs': similar_file_pairs,
        'detect_only_files': detect_only_files
    }

# NOTE: Cache projects' process result, needed for extract discrepancy code
proj_file_hash_and_line_map = {}
proj_diff_map_cache = {}

def reset_globals(proj_name = None, proj_version = None):
    global proj_file_hash_and_line_map
    if proj_name:
        if proj_version:
            proj_file_hash_and_line_map[proj_name].pop(proj_version)
        else:
            proj_file_hash_and_line_map.pop(proj_name)
    global proj_diff_map_cache
    proj_diff_map_cache = {}

def load_or_parse_project(proj_name, proj_version, proj_path):
    global proj_file_hash_and_line_map
    if proj_name in proj_file_hash_and_line_map \
        and proj_version in proj_file_hash_and_line_map[proj_name]:
        print(f'Cache hits: {proj_name}, {proj_version}')
        return proj_file_hash_and_line_map[proj_name][proj_version]
    else:
        if proj_path:
            proj_map = parse_files_from_proj(proj_path)
            if proj_name not in proj_file_hash_and_line_map:
                proj_file_hash_and_line_map[proj_name] = {}
            proj_file_hash_and_line_map[proj_name][proj_version] = proj_map
            
            return proj_map
        else:
            return None

def extract_discrepancy_files_and_code_lines(detect_name:str,
                                             detect_version:str,
                                             cand_name:str,
                                             cand_version:str,
                                            ):
    detect_map = load_or_parse_project(detect_name, detect_version, None)
    cand_map = load_or_parse_project(cand_name, cand_version, None)
    global proj_diff_map_cache
    detect_cand_diff_result = proj_diff_map_cache['-'.join([detect_name, detect_version, cand_name, cand_version])]

    discrepancy_code_results = []
    for (det_file_hash, cand_file_hash) in detect_cand_diff_result['similar_file_pairs']:
        discre_code_start_linenu = -1
        cand_code_lines_set = set(cand_map[cand_file_hash]['lines'])
        for line_nu, line in enumerate(detect_map[det_file_hash]['lines']):
            if line not in cand_code_lines_set:     # discrepancy code line
                discre_code_start_linenu = line_nu+1 if discre_code_start_linenu == -1 else discre_code_start_linenu
            else:                                   # not discrepancy code line
                if discre_code_start_linenu >= 0:
                    discre_code_end_linenu = line_nu
                    discrepancy_code_results.append(
                        FileDiffResult(
                            file=detect_map[det_file_hash]['file'],
                            benign_file=cand_map[cand_file_hash]['file'],
                            start_line=discre_code_start_linenu,
                            end_line=discre_code_end_linenu,
                            discrepency_code=detect_map[det_file_hash]['lines'][discre_code_start_linenu:discre_code_end_linenu+1]
                        )
                    )
                    discre_code_start_linenu = -1
        if discre_code_start_linenu >= 0:
            discrepancy_code_results.append(
                FileDiffResult(
                    file=detect_map[det_file_hash]['file'],
                    benign_file=cand_map[cand_file_hash]['file'],
                    start_line=discre_code_start_linenu,
                    end_line=len(detect_map[det_file_hash]['file']),
                    discrepency_code=detect_map[det_file_hash]['lines'][discre_code_start_linenu:]
                )
            )
    
    discrepancy_file_results = []
    for file_hash in detect_cand_diff_result['detect_only_files']:
        discrepancy_file_results.append(detect_map[file_hash]['file'])
    
    return discrepancy_code_results, discrepancy_file_results

# How to calculate the overall code similarity
def cal_overall_code_sim(cs_a, cs_b, mode='avg'):
    if mode == 'avg':
        return (cs_a + cs_b) / 2 
    elif mode == 'max':
        return cs_a if cs_a > cs_b else cs_b
    else:
        return (cs_a + cs_b) / 2


# Given many candidate existing projects, calculate code similarity 
def cal_code_sim(cand_projs:List, detect_name:str, detect_version:str, detect_path:str):
    """
        cand_projs: the same projects' different versions
        detect_one: the project need to be analyzed
    """
    detect_file_hash_and_line_map = load_or_parse_project(detect_name, detect_version, detect_path)
    detect_total_code_lines_count = sum(map(lambda x:len(x['lines']), detect_file_hash_and_line_map.values()), 0)
    
    # the detect project have no code, so it did not need to be processed next
    if detect_total_code_lines_count <= 0:
        return []

    max_pn, max_pv = '', ''
    max_code_sim, max_code_sim_upon_cand = 0.0, 0.0
    max_code_sim_result = []
    max_diff_res = {}
    for cp in cand_projs:
        pn, pv, pp = cp['name'], cp['version'], cp['path']
        cand_file_hash_line_map = load_or_parse_project(pn, pv, pp)
        cand_total_code_lines_count = sum(map(lambda x:len(x['lines']), cand_file_hash_line_map.values()), 0)
        
        if cand_total_code_lines_count <= 0:
            continue

        # FIRST: calculate the code similarity at line level
        diff_res = diff_between_proj_map(detect_file_hash_and_line_map, cand_file_hash_line_map)
        code_sim = diff_res['common_line_total'] / detect_total_code_lines_count            # ZeroDivisionError
        code_sim_upon_cand = diff_res['common_line_total'] / cand_total_code_lines_count    # ZeroDivisionError
        
        ## code similarity is 0, the candidate project may not be code confusion
        if code_sim <= 0.0 or code_sim_upon_cand <= 0.0:
            if len(max_code_sim_result) == 0:
                max_code_sim_result.append((pn, pv, pp, 0.0, 0.0))
            break
        
        # SECOND: update the maximum and save the most similar candidate projects
        if code_sim > max_code_sim or code_sim_upon_cand > max_code_sim_upon_cand: # the MAXIMUM one either climb up the most
            max_code_sim = code_sim
            max_code_sim_upon_cand = code_sim_upon_cand
            overall_sim = cal_overall_code_sim(max_code_sim, max_code_sim_upon_cand, mode='max')
            max_code_sim_result = [(pn, pv, pp, overall_sim, max_code_sim, max_code_sim_upon_cand)]
            max_diff_res = diff_res
            max_pn, max_pv = pn, pv 
    
    # cache the diff res prepared for next use
    global proj_diff_map_cache
    proj_diff_map_cache['-'.join([detect_name, detect_version, max_pn, max_pv])] = max_diff_res

    return max_code_sim_result
