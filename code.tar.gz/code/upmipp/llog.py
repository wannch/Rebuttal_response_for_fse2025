import logging
import os, sys
from typing import Dict
import uuid
import json

LOG_DIR = ''
LOGGER = None

def init(log_dir, filename:str):
    global LOG_DIR
    LOG_DIR = log_dir
    os.makedirs(LOG_DIR, exist_ok=True)

    global LOGGER
    LOGGER = logging.getLogger('')
    LOGGER.setLevel(logging.INFO)

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    filehandler = logging.FileHandler(os.path.join(log_dir, filename))
    filehandler.setLevel(logging.INFO)
    filehandler.setFormatter(formatter)
    LOGGER.addHandler(filehandler)

    streamhandler = logging.StreamHandler(sys.stdout)
    streamhandler.setLevel(logging.INFO)
    stream_formatter = logging.Formatter('%(message)s')
    streamhandler.setFormatter(stream_formatter)
    LOGGER.addHandler(streamhandler)

def log_msg(s:str):
    global LOGGER
    LOGGER.info(s)

def log_json(d:Dict, filename:str = None):
    if not filename:
        filename = str(uuid.uuid1())
    if len(d) > 0:
        with open(os.path.join(LOG_DIR, filename), 'w') as f:
            json.dump(d, f, indent=4)

