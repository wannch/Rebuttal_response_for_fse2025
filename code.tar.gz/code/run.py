import json
import time
from pprint import pprint
from tqdm import tqdm
from typing import List

import upmipp.likely_confusion as lc
import upmipp.verify_typo_effect as vte
from upmipp.utils import read_csv_records, load_embedding
import upmipp.pypi_pkg as pypi_pkg
import upmipp.proj_diff as pd
import upmipp.proj_diff_refactor as pdr
import upmipp.utils as utils
import upmipp.llog as llog
import upmipp.pkgs_getter as pkgs_getter
from upmipp.pkgs_getter import PackageInfo, get_new_pkgs

# parse and get all the meta data from projects
def parse_meta_from_batch_samples(samples:List[PackageInfo]):
    metas = []
    for sample in tqdm(samples):
        store_path = sample.extract_path
        
        meta = lc.parse_meta_from_projs(store_path)
        metas.append(meta)

    return metas

# embedding the readmes of samples
def embedding_readmes_from_batch_samples(sample_metas:List[PackageInfo]):
    sample_size = len(sample_metas)
    sample_idx_map_readme_idx = [-1] * sample_size
    
    readme_idx = 0
    readmes = [] # list of strs
    for i in range(len(sample_metas)):
        if sample_metas[i]['readme'] is not None:
            content_text = utils.get_markdown_pure_content(sample_metas[i]['readme'])
            readmes.append(content_text)
            sample_idx_map_readme_idx[i] = readme_idx
            readme_idx += 1
    
    # embedding
    readme_embeddings = utils.emb_text(readmes)
    return readme_embeddings, sample_idx_map_readme_idx

config = {
    'pkg_list_file': './resources/cate_pkgs/candidate_pkgs.csv',
    'readme_embeddings_file': './resources/pypi_project_readme_embbeding.pt',
    'pkg_list_with_readme_file': './resources/cate_pkgs/satisfied_pkg_names.csv',
    
    'readme_top_n': 10,
    'readme_similarity_threshold': 0.8,
    'code_similarity_threshold': 0.9,
    
    'pypi_new_pkg_dir': 'your_newly_uploaded_packages_save_dir',
    'pypi_pkg_cache_dir': './cache_pypi_package',
    'pkg_meta_save_dir': './pkg_meta',

    'log_dir': './pkg_scan_result'
}

def load_and_init():
    # load necessary files
    pkg_list = read_csv_records(config['pkg_list_file'])
    pkg_set = set(pkg_list) # transformed into set to speed up
    readme_embedding = load_embedding(config['readme_embeddings_file'])
    pkg_list_with_readme = read_csv_records(config['pkg_list_with_readme_file'])
    
    readme_top_n = config['readme_top_n']
    readme_similarity_threshold = config['readme_similarity_threshold']
    code_similarity_threshold = config['code_similarity_threshold']

    return pkg_list, pkg_set, readme_embedding, pkg_list_with_readme,\
            readme_top_n, readme_similarity_threshold, code_similarity_threshold

if __name__ == '__main__':
    pkg_list, pkg_set, readme_embedding, pkg_list_with_readme, \
        readme_top_n, readme_similarity_threshold, code_similarity_threshold = \
        load_and_init()
    select_which = config['select_which']
    start_datetime, end_datetime = config['start_datetime'], config['end_datetime']
    
    llog.init(config['log_dir'], f'log_{start_datetime}_{end_datetime}.txt')
    pkgs_getter.logger = llog.log_msg

    samples = None
    samples, err_info = get_new_pkgs(
                                config['pypi_new_pkg_dir'], 
                                date_range=(start_datetime, end_datetime), 
                                extract_mode=False
                            )
    llog.log_json(err_info, f'err_extract_info_{start_datetime}_{end_datetime}.json')

    total_start = time.time()

    # preprocess
    total = len(samples)
    llog.log_msg(f'Total samples needed to be processed: {total}')

    samples_metas = parse_meta_from_batch_samples(samples)
    assert total == len(samples_metas)
    samples_readme_embddings, sample_readme_idxs = embedding_readmes_from_batch_samples(samples_metas)
    llog.log_msg(f'Samples readme embedding size: {samples_readme_embddings.size()}')
    readme_similarity_scores = utils.calculate_similarity(samples_readme_embddings, readme_embedding)
    llog.log_msg(f'Readme similarity score size: {readme_similarity_scores.size()}')

    analysis_result_for_all_samples = []    # analysis results for all the samples
    # NOTE: process each sample needed to be analyzed
    for i, sample in enumerate(samples):
        llog.log_msg(f'Currently process {i}/{total}, {sample.name}, {sample.version}, {sample.extract_path}')
        
        single_sample_analysis_result = {
                                            **sample.to_dict(),
                                            'confusion_rank_scores':[],
                                            'code_confusion_above_thres':[],
                                            'code_confusion_all': [],
                                            'differentiate_result':{},
                                            'used_time':{}
                                        }
        
        sample_meta = samples_metas[i]
        readme_sim_score_vector = readme_similarity_scores[sample_readme_idxs[i]] if sample_readme_idxs[i] != -1 else None

        single_start = time.time()

        # SELECTION PHASE: for the confusion score 2 tolerance 
        selection_phase_start = time.time()

        # candidate projects of three confusion facets 
        proj_name_squatters, subdir_name_squatters, readme_squatters, readme_similarities = \
            lc.get_likely_code_squatters_new(
                                                sample.name,
                                                sample_meta,
                                                readme_sim_score_vector,
                                                pkg_set,
                                                pkg_list_with_readme,
                                                config['readme_top_n'],
                                                config['readme_similarity_threshold']
                                            )
        # rank candidate projects
        ranked_candidate_projects = lc.rank(proj_name_squatters, subdir_name_squatters, readme_squatters)
        selection_phase_end = time.time()
        
        # find the actually code confusion target projects
        score_2_tolerance_ct = 3
        code_confusion_above_thres, code_confusion_all = [], []
        sim_score_idx = 3
        candidate_count = len(ranked_candidate_projects)
        candidate_stop_idx = 0

        have_code = True
        
        identification_phase_start = time.time()
        download_and_cache_pkg_total = 0.0
        # pd.reset_globals()
        # process each candidate project for the sample
        for j, candidate_proj in enumerate(list(ranked_candidate_projects.keys())):
            candidate, score = candidate_proj, ranked_candidate_projects[candidate_proj]
            llog.log_msg(f'Compare code similarity for {j}th/{candidate_count}, proj name: {candidate}, rank score: {score}')
            
            if score == 2:
                score_2_tolerance_ct -= 1
            if score_2_tolerance_ct < 0:
                candidate_stop_idx += 1
                break
            
            download_and_cache_pkg_start = time.time()
            candidate_projs = \
                pypi_pkg.download_package_releases_and_extract(
                                                                candidate,
                                                                'all',
                                                                config['pkg_meta_save_dir'],
                                                                config['pypi_pkg_cache_dir'],
                                                                if_async=False,
                                                                if_sample_ver=False
                                                              )
            download_and_cache_pkg_end = time.time()
            download_and_cache_pkg_total += download_and_cache_pkg_end - download_and_cache_pkg_start
            
            # the benign package may has empty releases
            if candidate_projs is None or len(candidate_projs) == 0:
                continue
            
            # code_similarity = pd.find_most_sim(candidate_projs, sample.extract_path, ngram=20, sim_only=True)
            code_similarity = pdr.cal_code_sim(candidate_projs, sample.name, sample.version, sample.extract_path)
            # sample has no code
            if not code_similarity:
                have_code = False
                break
            code_confusion_all.append(code_similarity[0])

            # the highest similarity score compared to the target benign project
            if code_similarity[0][sim_score_idx] >= config['code_similarity_threshold']:
                code_confusion_above_thres.append(code_similarity[0])
                candidate_stop_idx += 1
                break
        
        if not have_code:
            llog.log_msg(f'{i}/{total}, {sample.name}, {sample.version}, has no code.')
            continue

        llog.log_msg(f'{i}/{total}, {sample.name}, {sample.version}, Code confusion above thres: {code_confusion_above_thres}')

        single_sample_analysis_result['confusion_rank_scores'] = ranked_candidate_projects
        # sort the code confusion result, only select the NOTE:1st result
        code_confusion_above_thres = sorted(code_confusion_above_thres, key=lambda x:x[sim_score_idx], reverse=True)
        single_sample_analysis_result['code_confusion_above_thres'] = code_confusion_above_thres
        code_confusion_all = sorted(code_confusion_all, key=lambda x:x[sim_score_idx], reverse=True)
        single_sample_analysis_result['code_confusion_all'] = code_confusion_all
        
        # Find code confusion target for the sample
        if len(code_confusion_above_thres) > 0:
            llog.log_msg(f'Count of projects that exceed thres: {len(code_confusion_above_thres)}')

            most_similar_projs = code_confusion_above_thres[0]  # the first most similar project
            # most similar projs := (pn, ver, sou, sim_score, len(inter_keys)/len(sou_ngram_key_set))
            # discrepency_code, discrepency_file = pd.diff_projs(most_similar_projs[0], most_similar_projs[1])
            discrepency_code, discrepency_file = pdr.extract_discrepancy_files_and_code_lines(
                detect_name=sample.name,
                detect_version=sample.version,
                cand_name=most_similar_projs[0],
                cand_version=most_similar_projs[1]
            )
            # save the result
            single_sample_analysis_result['differentiate_result']['legitimate_package'] = \
                {
                    'name':most_similar_projs[0],
                    'version':most_similar_projs[1],
                    'store_path':most_similar_projs[2],
                    'overall_code_sim':most_similar_projs[3],
                    'code_sim':most_similar_projs[4],
                    'code_sim_upon_legitimate':most_similar_projs[5],
                    'confusion_score':ranked_candidate_projects[most_similar_projs[0]]
                }
            single_sample_analysis_result['differentiate_result']['discrepency_code'] = [dc._asdict() for dc in discrepency_code]
            single_sample_analysis_result['differentiate_result']['discrepency_file'] = discrepency_file

        else:
            llog.log_msg(f"No code confusion projects with {config['code_similarity_threshold']} "
                  f"for: {sample.name}, {sample.version}, {sample.extract_path}")
        
        identification_phase_end = time.time()

        single_end = time.time()
        # PROCESS used time
        used_time = {
            'total_cost': round(single_end - single_start, 2),
            'selection_phase': round(selection_phase_end - selection_phase_start, 2),
            'download_and_cache_pkg_total': download_and_cache_pkg_total,
            'identification_phase': round(identification_phase_end - identification_phase_start, 2) - download_and_cache_pkg_total
        }
        single_sample_analysis_result['used_time'] = used_time
        analysis_result_for_all_samples.append(single_sample_analysis_result)
        
        llog.log_msg(f'Finished {i}/{total}, {sample.name}, {sample.version}, {single_end - single_start:.2f}s, {candidate_stop_idx}/{candidate_count}')

    # save the analysis result to JSON file
    llog.log_json(analysis_result_for_all_samples, filename=f'pypi_batch_{start_datetime}_{end_datetime}.json')
    total_end = time.time()
    llog.log_msg(f'Total used time:{utils.transform_to_hms(int(total_end - total_start))}.')
