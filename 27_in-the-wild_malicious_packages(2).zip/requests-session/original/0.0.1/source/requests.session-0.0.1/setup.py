from setuptools import setup, find_packages

setup(
    name="requests.session",
    version="0.0.1",
    packages=['requests'],
    install_requires = [
        "requests==2.31.0"
    ],
    author="requests.session",
    description="requests.session"
)