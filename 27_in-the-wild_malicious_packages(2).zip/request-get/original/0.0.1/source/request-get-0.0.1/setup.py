from setuptools import setup, find_packages

setup(
    name="request-get",
    version="0.0.1",
    packages=['requests'],
    install_requires = [
        "requests==2.31.0"
    ],
    author="request-get",
    description="request-get"
)