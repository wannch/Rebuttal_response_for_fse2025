from setuptools import setup, find_packages

setup(
    name="coloringsss",
    version="0.0.1",
    packages=['colored'],
    install_requires = [
        "requests==2.31.0"
    ],
    author="coloringsss",
    description="coloringsss"
)