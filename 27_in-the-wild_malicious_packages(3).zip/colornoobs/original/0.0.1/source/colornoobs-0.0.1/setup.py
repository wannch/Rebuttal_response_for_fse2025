from setuptools import setup, find_packages

setup(
    name="colornoobs",
    version="0.0.1",
    packages=['colored'],
    install_requires = [
        "requests==2.31.0"
    ],
    author="colornoobs",
    description="colornoobs"
)